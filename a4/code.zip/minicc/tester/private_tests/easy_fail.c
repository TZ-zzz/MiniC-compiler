// Semantic fail 3

void main() {
    bool x;
    int y;

    y = 1;
    x = true;
    -x;
    !y;
}