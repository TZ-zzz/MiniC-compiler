int alpha;
bool delta;
void main() {
    alpha = 1;
    delta = false;

    gamma;

    alpha + delta * 3;

    delta / 4;


}