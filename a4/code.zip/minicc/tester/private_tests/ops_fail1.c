int alpha;
bool delta;
void main() {
    alpha = 1;
    delta = false;

    alpha * 3 + delta;

    alpha == delta;

    alpha != delta;

    alpha < delta;

    alpha > delta;

    alpha <= delta;

    alpha >= delta;
    
}