//
// Created by Fan Long on 12/3/20.
//

#ifndef MINICC_ASTCHECKER_H
#define MINICC_ASTCHECKER_H

#include <string>

void checkASTStatus(const std::string &InputFile);

#endif //MINICC_ASTCHECKER_H
