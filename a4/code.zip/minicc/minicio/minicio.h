extern int getint();

extern void putint(int v);

extern void putnewline();
