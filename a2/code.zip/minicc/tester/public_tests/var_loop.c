// Test 2: Loops

int x;
int arr[10];

int main() {
    x = 5;
    for (x = 0; x < 10; x = x + 1)
        arr[x] = x;
    return 0;
}